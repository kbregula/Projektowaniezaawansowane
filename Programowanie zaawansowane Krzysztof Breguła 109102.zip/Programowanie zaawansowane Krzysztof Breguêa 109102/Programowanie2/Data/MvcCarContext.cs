﻿using Microsoft.EntityFrameworkCore;
using Programowanie2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Programowanie2.Data
{
    public class MvcCarContext : DbContext
    {
        public MvcCarContext(DbContextOptions<MvcCarContext> options)
        : base(options)
        {
        }
        public DbSet<Car> Car { get; set; }
    }
}
