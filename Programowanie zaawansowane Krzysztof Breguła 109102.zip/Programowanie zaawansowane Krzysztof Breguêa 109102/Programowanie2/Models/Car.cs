﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Programowanie2.Models
{
    public class Car
    {
        public int Id { get; set; }
        public string Marka { get; set; }
        [DataType(DataType.Date)]
        public DateTime DataProdukcji { get; set; }
        public string Typ { get; set; }
        public decimal Cena { get; set; }
    }
}
