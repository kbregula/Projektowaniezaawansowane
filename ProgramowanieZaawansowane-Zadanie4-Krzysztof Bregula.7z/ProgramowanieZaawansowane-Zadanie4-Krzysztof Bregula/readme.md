Krzysztof Breguła 109102
